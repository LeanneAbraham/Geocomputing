'''
This script sets the variable i to 0, then runs
a while statement, incrementing i by one until
the condition "i < 4" is not met (i.e. when i equals 4);
the while statement then ends.
'''

i = 0

while i < 4:
    print 'the value of i is:', i
    i+=1

print 'the while loop has finished'
