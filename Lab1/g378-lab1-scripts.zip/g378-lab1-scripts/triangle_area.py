# This program calculates the area of a triangle.

# [explain]
print "This program finds the area of a triangle."
print 	

# [explain]
height = input("Please enter the height of the triangle: ")
base = input("Please enter the base length of the triangle: ")

# [explain]
area = 0.5 * height * base

# [explain]
print "The area of a triangle with height", height, "and base", base, "is", area, "."
